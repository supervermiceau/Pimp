DROP TABLE Est_interdit cascade constraints;
DROP TABLE Creer_liste cascade constraints;
DROP TABLE convient_a cascade constraints;
DROP TABLE Composer cascade constraints;
DROP TABLE Possede cascade constraints;
DROP TABLE Regime cascade constraints;

DROP TABLE INGREDIENT cascade constraints;

DROP TABLE Categorie cascade constraints;
DROP TABLE Login cascade constraints;

DROP TABLE Archives_liste_achat cascade constraints;
DROP TABLE Archive_planning cascade constraints;
DROP TABLE Planning cascade constraints;
DROP TABLE Etape cascade constraints;
DROP TABLE RECETTE cascade constraints;
DROP TABLE UTILISATEUR cascade constraints;
